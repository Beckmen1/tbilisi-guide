// Mobile menu
const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');

menuToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

mainNav.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

// Slider
const slider = document.getElementById('slider');
const slides = slider.querySelectorAll('.slide');
const dotsBox = document.getElementById('dots');
let current = 0;
let timer;

slides.forEach((_, i) => {
  const dot = document.createElement('button');
  dot.className = 'dot';
  dot.setAttribute('aria-label', `სლაიდი ${i + 1}`);
  dot.addEventListener('click', () => { showSlide(i); restartTimer(); });
  dotsBox.appendChild(dot);
});
const dots = dotsBox.querySelectorAll('.dot');

function showSlide(index) {
  slides[current].classList.remove('active');
  dots[current].classList.remove('active');
  current = (index + slides.length) % slides.length;
  slides[current].classList.add('active');
  dots[current].classList.add('active');
}

function startTimer() { timer = setInterval(() => showSlide(current + 1), 5000); }
function restartTimer() { clearInterval(timer); startTimer(); }

document.getElementById('prevBtn').addEventListener('click', () => { showSlide(current - 1); restartTimer(); });
document.getElementById('nextBtn').addEventListener('click', () => { showSlide(current + 1); restartTimer(); });

slider.addEventListener('mouseenter', () => clearInterval(timer));
slider.addEventListener('mouseleave', startTimer);
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') { showSlide(current - 1); restartTimer(); }
  if (e.key === 'ArrowRight') { showSlide(current + 1); restartTimer(); }
});

showSlide(0);
startTimer();

// Contact form validation
const form = document.getElementById('contactForm');
const success = document.getElementById('formSuccess');

function setError(input, message) {
  input.parentElement.classList.toggle('invalid', Boolean(message));
  document.getElementById(`${input.id}Error`).textContent = message;
  return !message;
}

function validateName() {
  const name = form.elements.name;
  return setError(name, name.value.trim().length < 2 ? 'შეიყვანეთ სახელი (მინიმუმ 2 სიმბოლო)' : '');
}

function validateEmail() {
  const email = form.elements.email;
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
  return setError(email, ok ? '' : 'შეიყვანეთ სწორი ელფოსტა');
}

function validateMessage() {
  const message = form.elements.message;
  return setError(message, message.value.trim().length < 10 ? 'შეტყობინება მინიმუმ 10 სიმბოლოს უნდა შეიცავდეს' : '');
}

form.elements.name.addEventListener('blur', validateName);
form.elements.email.addEventListener('blur', validateEmail);
form.elements.message.addEventListener('blur', validateMessage);

form.addEventListener('submit', (e) => {
  e.preventDefault();
  success.textContent = '';
  const valid = [validateName(), validateEmail(), validateMessage()].every(Boolean);
  if (valid) {
    success.textContent = 'მადლობა! თქვენი შეტყობინება მიღებულია.';
    form.reset();
  }
});
